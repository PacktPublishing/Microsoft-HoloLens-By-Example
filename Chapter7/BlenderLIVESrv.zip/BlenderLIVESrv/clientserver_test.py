import socket
import threading
import time


class Client(threading.Thread):

    def __init__(self, conn, addr, receiveDataHandler, connectionClosedHandler):
        threading.Thread.__init__(self)

        self.conn = conn
        self.addr = addr

        self.alive = threading.Event()
        self.alive.set()

        self.receiveDataHandler = receiveDataHandler
        self.connectionClosedHandler = connectionClosedHandler

    def run(self):
        while self.alive.isSet():
            self.receive()
            time.sleep(0.2)

        print("client loop ending {}".format(self.addr))

    def join(self, timeout=None):
        if self.connectionClosedHandler:
            self.connectionClosedHandler(self.addr)

        self.alive.clear()
        threading.Thread.join(self, timeout)

    def send(self, msg):
        self.conn.send(msg)

        self.conn.close()

    def close(self):
        self.alive.clear()

    def receive(self, buffer=2056):
        try:
            data = self.conn.recv(buffer)

            if data and self.receiveDataHandler:
                self.receiveDataHandler(self.addr, data)

        except ConnectionResetError as cre:
            self.alive.clear()

            if self.connectionClosedHandler:
                self.connectionClosedHandler(self.addr)


class Server(threading.Thread):

    def __init__(self, port=5559, on_clients_updated=None, on_client_data_received=None):
        threading.Thread.__init__(self)

        self.on_clients_updated = on_clients_updated
        self.on_client_data_received = on_client_data_received

        self.clients = {}

        self.host = ''
        self.port = port

        self.alive = threading.Event()
        self.alive.set()

        self.socket = None

        self.start()

    def run(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.socket.bind((self.host, self.port))
        except socket.error as msg:
            raise msg

        self.socket.listen()

        while self.alive.isSet():
            conn, addr = self.socket.accept()
            addr = "{}:{}".format(addr[0], addr[1])

            self.clients[addr] = Client(conn,
                                        addr,
                                        self.on_client_data_received,
                                        self.on_client_disconnected)

            self.clients[addr].start()

            self.on_client_connected(addr)

    def close(self, timeout=None):
        self.alive.clear()
        threading.Thread.join(self, timeout)

    def on_client_connected(self, addr):
        print("on client connected {}".format(addr))
        if self.on_clients_updated:
            self.on_clients_updated()

    def on_client_disconnected(self, addr):
        if addr not in self.clients:
            return

        print("disconnecting client {}".format(addr))
        del self.clients[addr]

        if self.on_clients_updated:
            self.on_clients_updated()

    def on_client_data_received(self, addr, data):
        print("{} {}".format(addr, str(data)))

        if self.on_client_data_received:
            self.on_client_data_received(addr, data)

    def broadcast(self, data, source_addr=None):
        for client_addr, client in self.clients.items():
            if client_addr == source_addr or source_addr == None:
                client.send(data)

server = Server()

