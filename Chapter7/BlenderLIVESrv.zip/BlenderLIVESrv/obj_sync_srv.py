
import threading
from .singleton import Singleton
import bpy
import time
import sys
import socket
import queue
import struct
import json


class Client(threading.Thread):

    def __init__(self, conn, addr, receiveDataHandler, connectionClosedHandler):
        threading.Thread.__init__(self)

        self.conn = conn
        self.addr = addr

        self.alive = threading.Event()
        self.alive.set()

        self.receiveDataHandler = receiveDataHandler
        self.connectionClosedHandler = connectionClosedHandler

        self.worldAnchorId = -1

        self.remainingByteToReceive = 0
        self.recievedBytesbuffer = None

        self.empty_packeted_received_counter = 0

    def run(self):
        print("entering client loop {}".format(self.addr))

        while self.alive.isSet():
            self.receive()
            time.sleep(0.2)

        print("exiting client loop {}".format(self.addr))

    def join(self, timeout=None):
        if self.connectionClosedHandler:
            self.connectionClosedHandler(self.addr)

        self.alive.clear()
        threading.Thread.join(self, timeout)

    def send(self, msg):
        try:
            self.conn.send(msg)
        except Exception as e:
            print("send error {}".format(e))
            self.alive.clear()

            if self.connectionClosedHandler:
                self.connectionClosedHandler(self.addr)

    def close(self):
        print("client close")

        self.alive.clear()

    def receive(self, buffer=128000):
        try:
            data = self.conn.recv(buffer)

            if data is None or len(data) == 0:
                print("empty packet received from client {}".format(self.addr))

                self.empty_packeted_received_counter += 1

                if self.empty_packeted_received_counter < 5:
                    return

                raise Exception('Received too many empty packets')

            self.empty_packeted_received_counter = 0

            if self.remainingByteToReceive > 0:
                self.remainingByteToReceive -= len(data)
                self.recievedBytesbuffer = self.recievedBytesbuffer + data
            else:
                packet_size = struct.unpack("<i", data[1:1+4])[0]

                self.remainingByteToReceive = packet_size - len(data)
                self.recievedBytesbuffer = data

            if self.remainingByteToReceive <= 0:
                self.remainingByteToReceive = 0
                self.receiveDataHandler(self.addr, self.recievedBytesbuffer)

        except ConnectionResetError as cre:
            print("receive error {}".format(cre))
            self.alive.clear()

            if self.connectionClosedHandler:
                self.connectionClosedHandler(self.addr)

        except Exception as e:
            print("receive error {}".format(e))
            self.alive.clear()

            if self.connectionClosedHandler:
                self.connectionClosedHandler(self.addr)


class ObjectSyncService(metaclass=Singleton):

    def __init__(self, port=8080, service_broadcast_address='239.1.1.1', service_broadcast_port=8881, service_broadcast_timing=3):

        self.on_client_connected_handler = None
        self.on_client_disconnected_handler = None
        self.on_client_data_received_handler = None

        self.clients = {}

        self.host = ''
        self.port = port

        self.service_broadcast_address = service_broadcast_address  # multicast address
        self.service_broadcast_port = service_broadcast_port
        self.service_broadcast_timing = service_broadcast_timing

        self.listening_thread = None
        self.packet_queue_thread = None
        self.srv_broadcast_thread = None

        self.packet_queue = queue.Queue()
        self.packet_queue_counts = {}

        self.alive = threading.Event()
        self.alive.set()

        self.socket = None

    def reset(self):
        self.clients = {}
        self.packet_queue = queue.Queue()
        self.packet_queue_counts = {}

        self.alive = threading.Event()
        self.alive.set()

    def start(self):
        print("ObjectSyncService.start")

        self.reset()

        self.listening_thread = threading.Thread(target=self.client_connection_loop)
        self.listening_thread.start()

        self.packet_queue_thread = threading.Thread(target=self.packet_queue_loop)
        self.packet_queue_thread.start()

        self.srv_broadcast_thread = threading.Thread(target=self.service_broadcast_loop)
        self.srv_broadcast_thread.start()

    def client_connection_loop(self):
        print('entering server loop')

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 512000)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 512000)

        try:
            self.socket.bind((self.host, self.port))
        except socket.error as msg:
            raise msg

        self.socket.listen()

        while self.alive.isSet():
            try:
                conn, addr = self.socket.accept()
                addr = "{}:{}".format(addr[0], addr[1])

                self.clients[addr] = Client(conn,
                                            addr,
                                            self.on_client_data_received,
                                            self.on_client_disconnected)

                self.clients[addr].start()

                self.on_client_connected(addr)

            except OSError as e:
                return

        print('exiting server loop')

    def enqueue_packet(self, packet_id, packet, source_addr=None, target_addrs=None):
        print("enqueue_packet: id {}, len {}, source {}, target {}".format(
            packet_id,
            len(packet),
            source_addr,
            target_addrs))

        if packet_id not in self.packet_queue_counts:
            self.packet_queue_counts[packet_id] = 0

        self.packet_queue_counts[packet_id] += 1

        self.packet_queue.put((packet_id, packet, source_addr, target_addrs))

    def packet_queue_loop(self):
        print("entering - packet_queue_loop")

        while self.alive.isSet():
            while not self.packet_queue.empty() and self.alive.isSet():
                packet_id, packet, source_addr, target_addrs = self.packet_queue.get()

                self.packet_queue_counts[packet_id] -= 1

                if self.packet_queue_counts[packet_id] < 1:
                    self.send(packet, source_addr, target_addrs)

                time.sleep(0.1)

            time.sleep(0.2)

        print("exiting - packet_queue_loop")

    def service_broadcast_loop(self):
        print("entering - service_broadcast_loop")

        udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        udp_socket.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, self.service_broadcast_timing)

        udp_socket.settimeout(0.2)

        #multicast_addr = (self.service_broadcast_address, self.service_broadcast_port)

        while self.alive.isSet():
            udp_socket.sendto('blenderlive:{}'.format(self.port).encode(), ('<broadcast>', self.service_broadcast_port))
            #udp_socket.sendto('blenderlive'.encode(), multicast_addr)
            time.sleep(self.service_broadcast_timing)

        udp_socket.close()

        print("exiting - service_broadcast_loop")

    def stop(self, timeout=1):
        print("ObjectSyncService.stopping...")

        for client_addr, client in self.clients.items():
            client.close()

        self.clients.clear()

        self.alive.clear()

        self.socket.close()

        # stop all threads
        threading.Thread.join(self.listening_thread, timeout)
        threading.Thread.join(self.packet_queue_thread, timeout)

        print("ObjectSyncService.stopped")

    def on_client_connected(self, addr):
        print("on client connected {}".format(addr))

        if self.on_client_connected_handler:
            self.on_client_connected_handler(addr)

    def on_client_disconnected(self, addr):
        if addr not in self.clients:
            return

        print("disconnecting client {}".format(addr))
        del self.clients[addr]

        if self.on_client_disconnected_handler:
            self.on_client_disconnected_handler(addr)

    def on_client_data_received(self, addr, data):
        print("on_client_data_received, from {}, size {}".format(addr, len(data)))

        if self.on_client_data_received_handler:
            self.on_client_data_received_handler(addr, data)

    def send(self, data, source_addr=None, target_addrs=[]):
        print("sending packet of size {}".format(len(data)))

        client_addrs = list(self.clients)

        for client_addr in client_addrs:
            if client_addr not in target_addrs:
                continue

            try:
                client = self.clients[client_addr]
                client.send(data)
            except:
                pass

