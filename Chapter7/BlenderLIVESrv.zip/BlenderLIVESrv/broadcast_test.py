import threading
import time
import sys
import socket
import queue
import json
import select


def service_broadcast_loop(port=8881, broadcast_timing=3):
    print("entering - service_broadcast_loop")

    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    udp_socket.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 20)
    #udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    #udp_socket.setblocking(0)
    #udp_socket.bind(('', 0))

    broadcasting = True

    while broadcasting:
        udp_socket.sendto('blenderlive'.encode(), ('<broadcast>', port))
        time.sleep(broadcast_timing)

    udp_socket.close()

    print("exiting - service_broadcast_loop")

srv_broadcast_thread = threading.Thread(target=service_broadcast_loop)
srv_broadcast_thread.start()