
from .singleton import Singleton
import io
import os
import time
import math
import bpy
import mathutils
import bmesh
from mathutils import Vector, Matrix
from functools import reduce
import json
import struct


def add_to_buffer(buffer, fmt, vals):
    if buffer:
        return struct.pack_into(buffer, fmt, *vals)
    else:
        return struct.pack(fmt, *vals)


class SceneObject(object):
    """
    Data object representing a geometric object in the blender scene
    """
    def __init__(self, name, mode, transform, vertices, normals, faces, uvs, materials):
        self.name = name
        self.mode = mode
        self.transform = transform
        self.vertices = vertices
        self.normals = normals
        self.faces = faces
        self.uvs = uvs
        self.materials = materials
        self.children = []

    def find_material_with_texture(self, texture_name):
        if self.materials is not None:
            for mat in self.materials:
                if 'face_image' in mat and mat['face_image'] is not None:
                    if mat['face_image'].lower() == texture_name.lower():
                        return mat

        if self.children is not None:
            for child in self.children:
                mat = child.find_material_with_texture(texture_name)
                if mat is not None:
                    return mat

        return None

    def get_pack_fmt_and_bytes(self, deep_copy = True, fmt= "<", data=[]):
        # add name
        fmt += "B{}s".format(len(self.name))
        data.append(len(self.name))
        data.append(bytes(self.name, 'utf-8'))

        # mode
        fmt += "B{}s".format(len(self.mode))
        data.append(len(self.mode))
        data.append(bytes(self.mode, 'utf-8'))

        # transform
        fmt += "{}f".format(len(self.transform))
        data.extend(self.transform)

        if deep_copy:
            # includes mesh data
            fmt += "B"
            data.append(1)

            # verts
            fmt += "i{}f".format(len(self.vertices))
            data.append(len(self.vertices))
            data.extend(self.vertices)

            # normals
            fmt += "i{}f".format(len(self.normals))
            data.append(len(self.normals))
            data.extend(self.normals)

            # faces
            fmt += "i{}i".format(len(self.faces))
            data.append(len(self.faces))
            data.extend(self.faces)

            # uvs
            fmt += "i{}f".format(len(self.uvs))
            data.append(len(self.uvs))
            data.extend(self.uvs)

            # materials
            fmt += "i"
            data.append(len(self.materials))
            for mat in self.materials:
                fmt, data = self.get_pack_fmt_and_data_for_materials(mat, fmt, data)

        else:
            # DOESN'T include mesh data
            fmt += "B"
            data.append(0)

        # children
        fmt += "i"
        data.append(len(self.children))
        for child in self.children:
            fmt, data = child.get_pack_fmt_and_bytes(deep_copy, fmt, data)

        return fmt, data

    def get_pack_fmt_and_data_for_materials(self, mat, fmt, data):
        # name
        fmt += "B{}s".format(len(mat['name']))
        data.append(len(mat['name']))
        data.append(bytes(mat['name'], 'utf-8'))

        # specular_hardness
        fmt += "f"
        data.append(mat['specular_hardness'])

        # ambient_color
        fmt += '3f'
        data.extend(mat['ambient_color'])

        # alpha
        fmt += "f"
        data.append(mat['alpha'])

        # diffuse_color
        fmt += '3f'
        data.extend(mat['diffuse_color'])

        # emit_color
        fmt += '3f'
        data.extend(mat['emit_color'])

        # has texture image
        fmt += 'B'
        data.append(1 if 'face_image' in mat else 0)

        if 'face_image' in mat:

            # width
            fmt += "i"
            data.append(int(mat['face_image_width']))

            # height
            fmt += "i"
            data.append(int(mat['face_image_height']))

            fmt += "B{}s".format(len(mat['face_image']))
            data.append(len(mat['face_image']))
            data.append(bytes(mat['face_image'], 'utf-8'))

        return fmt, data

    def to_bytes(self):
        return struct.pack(*self.get_pack_fmt_and_bytes())

    def to_dict(self):
        dict = {
            'name': self.name,
            'mode': self.mode,
            'transform': self.transform,
            'vertices': self.vertices,
            'normals': self.normals,
            'faces': self.faces,
            'uvs': self.uvs,
            'materials': self.materials,
            'children': []
        }

        for child in self.children:
            dict['children'].append(child.to_dict())

        return dict

    def to_json(self):
        return json.dumps(self.to_dict())


class SceneObjectParser:
    """
    Serailise a object from a Blender scene
    """

    @staticmethod
    def name_compat(name):
        if name is None:
            return 'None'
        else:
            return name.replace(' ', '_')

    @staticmethod
    def get_mesh(obj, cloning_mesh=True):
        me = obj.data

        if cloning_mesh:
            me = me.copy()

        if me.is_editmode:
            bm = bmesh.from_edit_mesh(me)
            bmesh.ops.triangulate(bm, faces=bm.faces)
            bm.to_mesh(me)
        else:
            bm = bmesh.new()
            bm.from_mesh(me)
            bmesh.ops.triangulate(bm, faces=bm.faces)
            bm.to_mesh(me)

        bm.free()
        del bm

        return me

    @staticmethod
    def veckey2d(v):
        return round(v[0], 4), round(v[1], 4)

    @staticmethod
    def veckey3d(v):
        return round(v.x, 4), round(v.y, 4), round(v.z, 4)

    @staticmethod
    def export_mat(obj, scene, mtl_dict):
        export = []

        mtl_dict_values = list(mtl_dict.values())

        mtl_dict_values.sort(key=lambda m: m[0])

        for mtl_mat_name, mat, face_img in mtl_dict_values:
            export_mat = {}

            if not mat:
                continue

            export_mat['name'] = mtl_mat_name

            if mat.specular_shader == 'WARDISO':
                export_mat['specular_hardness'] = (0.4 - mat.specular_slope) / 0.0004
            else:
                export_mat['specular_hardness'] = (mat.specular_hardness - 1) / 0.51

            export_mat['ambient_color'] = [mat.ambient, mat.ambient, mat.ambient]

            export_mat['alpha'] = mat.alpha

            tmp = (mat.diffuse_intensity * mat.diffuse_color)[:]
            export_mat['diffuse_color'] = [tmp[0], tmp[1], tmp[2]]

            tmp = (mat.diffuse_intensity * mat.specular_color)[:]
            export_mat['specular_color'] = [tmp[0], tmp[1], tmp[2]]

            tmp = (mat.emit * mat.diffuse_color)[:]
            export_mat['emit_color'] = [tmp[0], tmp[1], tmp[2]]

            if face_img:
                filepath = face_img.filepath
                if filepath:
                    # filepath = face_img.library
                    export_mat['face_image'] = filepath
                    export_mat['face_image_width'] = face_img.size[0]
                    export_mat['face_image_height'] = face_img.size[1]

            image_map = {}
            # backwards so topmost are highest priority
            for mtex in reversed(mat.texture_slots):
                if mtex and mtex.texture and mtex.texture.type == 'IMAGE':
                    image = mtex.texture.image
                    if image:
                        if (mtex.use_map_color_diffuse and (face_img is None) and
                                (mtex.use_map_warp is False) and (mtex.texture_coords != 'REFLECTION')):
                            image_map["map_reflection"] = (mtex, image)

                        if mtex.use_map_ambient:
                            image_map["map_ambient"] = (mtex, image)

                        if mtex.use_map_color_spec:  # specular color
                            image_map["map_specular"] = (mtex, image)

                        if mtex.use_map_hardness:  # specular hardness/glossiness
                            image_map["map_hardness"] = (mtex, image)

                        if mtex.use_map_alpha:
                            image_map["map_alpha"] = (mtex, image)

                        if mtex.use_map_translucency:
                            image_map["map_translucency"] = (mtex, image)

                        if mtex.use_map_normal:
                            image_map["map_bump"] = (mtex, image)

                        if mtex.use_map_displacement:
                            image_map["disp"] = (mtex, image)

                        if mtex.use_map_color_diffuse and (mtex.texture_coords == 'REFLECTION'):
                            image_map["refl"] = (mtex, image)

                        if mtex.use_map_emit:
                            image_map["map_emit"] = (mtex, image)

            tex_maps = []

            for key, (mtex, image) in sorted(image_map.items()):
                filepath = image.filepath
                options = []
                if key == "map_bump":
                    if mtex.normal_factor != 1.0:
                        options.append('-bm %.6f' % mtex.normal_factor)

                    if mtex.offset != Vector((0.0, 0.0, 0.0)):
                        options.append('-o %.6f %.6f %.6f' % mtex.offset[:])

                    if mtex.scale != Vector((1.0, 1.0, 1.0)):
                        options.append('-s %.6f %.6f %.6f' % mtex.scale[:])

                    if options:
                        tex_maps.append({'map': key,'options': options,'image': filepath})
                    else:
                        tex_maps.append({'map': key,'image': filepath})

            export_mat['maps'] = tex_maps

            export.append(export_mat)

        return export

    @staticmethod
    def export_mesh(obj, trans_mat, scene):
        print("exporting mesh {}".format(obj.name))

        uv_unique_count = no_unique_count = 0

        cloning_mesh = True
        me = SceneObjectParser.get_mesh(obj, cloning_mesh)

        faceuv = len(me.uv_textures) > 0
        if faceuv:
            uv_texture = me.uv_textures.active.data[:]
            uv_layer = me.uv_layers.active.data[:]

        me_verts = me.vertices[:]

        face_index_pairs = [(face, index) for index, face in enumerate(me.polygons)]

        me.calc_normals_split()

        loops = me.loops

        # A Dict of Materials
        # (material.name, image.name):matname_imagename # matname_imagename has gaps removed.
        mtl_dict = {}

        # Used to reduce the usage of matname_texname materials, which can become annoying in case of
        # repeated exports/imports, yet keeping unique mat names per keys!
        # mtl_name: (material.name, image.name)
        mtl_rev_dict = {}

        materials = me.materials[:]
        material_names = [m.name if m else None for m in materials]

        if not materials:
            materials = [None]
            material_names = [SceneObjectParser.name_compat(None)]

        totverts = totuvco = totno = 1

        export = {}

        name1 = obj.name
        name2 = obj.data.name
        if name1 == name2:
            obnamestring = SceneObjectParser.name_compat(name1)
        else:
            obnamestring = '%s_%s' % (SceneObjectParser.name_compat(name1), SceneObjectParser.name_compat(name2))

        export['name'] = obnamestring

        # verts
        export['verts'] = []
        for v in me_verts:
            t_co = trans_mat * v.co
            export['verts'].append([t_co[0], t_co[1], t_co[2]])

        # uvs
        export['uvs'] = []
        if faceuv:
            uv = f_index = uv_index = uv_key = uv_val = uv_ls = None

            uv_face_mapping = [None] * len(face_index_pairs)
            uv_dict = {}
            uv_get = uv_dict.get

            for f, f_index in face_index_pairs:
                uv_ls = uv_face_mapping[f_index] = []
                for uv_index, l_index in enumerate(f.loop_indices):
                    uv = uv_layer[l_index].uv

                    uv_key = loops[l_index].vertex_index, SceneObjectParser.veckey2d(uv)

                    uv_val = uv_get(uv_key)
                    if uv_val is None:
                        uv_val = uv_dict[uv_key] = uv_unique_count
                        export['uvs'].append([uv[0], uv[1]])
                        uv_unique_count += 1
                    uv_ls.append(uv_val)

            del uv_dict, uv, f_index, uv_index, uv_ls, uv_get, uv_key, uv_val

        # normals
        export['normals'] = []
        no_key = no_val = None
        normals_to_idx = {}
        no_get = normals_to_idx.get
        loops_to_normals = [0] * len(loops)

        for f, f_index in face_index_pairs:
            for l_idx in f.loop_indices:
                no_key = SceneObjectParser.veckey3d(loops[l_idx].normal)
                no_val = no_get(no_key)
                if no_val is None:
                    no_val = normals_to_idx[no_key] = no_unique_count
                    export['normals'].append([no_key[0], no_key[1], no_key[2]])
                    no_unique_count += 1
                loops_to_normals[l_idx] = no_val

        del normals_to_idx, no_get, no_key, no_val

        # faces
        export["faces"] = []

        for f, f_index in face_index_pairs:
            f_mat = min(f.material_index, len(materials) - 1)

            tface = None
            f_image = None

            if faceuv:
                tface = uv_texture[f_index]
                f_image = tface.image

            # MAKE KEY
            if faceuv and f_image:  # Object is always true.
                key = material_names[f_mat], f_image.name
            else:
                key = material_names[f_mat], None  # No image, use None instead

            if key[0] is None and key[1] is None:
                export["usemtl"] = "(null)"
            else:
                mat_data = mtl_dict.get(key)

                if not mat_data:
                    mtl_name = "%s" % SceneObjectParser.name_compat(key[0])
                    if mtl_rev_dict.get(mtl_name, None) not in {key, None}:
                        if key[1] is None:
                            tmp_ext = "_NONE"
                        else:
                            tmp_ext = "_%s" % SceneObjectParser.name_compat(key[1])

                        i = 0
                        while mtl_rev_dict.get(mtl_name + tmp_ext, None) not in {key, None}:
                            i += 1
                            tmp_ext = "_%3d" % i

                        mtl_name += tmp_ext

                    mat_data = mtl_dict[key] = mtl_name, materials[f_mat], f_image
                    mtl_rev_dict[mtl_name] = key

                    export["usemtl"] = mat_data[0]

            f_v = [(vi, me_verts[v_idx], l_idx) for vi, (v_idx, l_idx) in enumerate(zip(f.vertices, f.loop_indices))]

            if faceuv:
                for vi, v, li in f_v:
                    export["faces"].append([totverts + v.index - 1,
                                            totno + loops_to_normals[li] - 1,
                                            totuvco + uv_face_mapping[f_index][vi] - 1])  # vert, normal, uv
            else:
                for vi, v, li in f_v:
                    export["faces"].append([totverts + v.index - 1,
                                             totno + loops_to_normals[li] - 1])

        # align normals and uvs with verts
        # print("aligning mesh data; verts {}, uvs {}, normals {}, faces {}".format(
        #     len(export['verts']),
        #     len(export['uvs']),
        #     len(export['normals']),
        #     len(export['faces'])
        # ))

        array_len = max(len(export['uvs']), len(export['normals']), len(export['verts']))
        aligned_verts = [[0., 0., 0.]] * array_len
        aligned_uvs = [[0., 0.]] * array_len
        aligned_normals = [[0., 0., 0.]] * array_len
        aligned_f = []

        face_keys = {}

        for f_tuples in export["faces"]:
            vert_idx = f_tuples[0]
            norm_idx = f_tuples[1]
            if faceuv:
                uv_idx = f_tuples[2]
                face_key = (vert_idx, norm_idx, uv_idx)
            else:
                face_key = (vert_idx, norm_idx)

            if face_key not in face_keys:
                face_keys[face_key] = len(face_keys)

            idx = face_keys[face_key]

            if idx >= len(aligned_verts):
                aligned_verts.append(export['verts'][vert_idx])
                aligned_normals.append(export['normals'][norm_idx])
                if faceuv:
                    aligned_uvs.append(export['uvs'][uv_idx])
            else:
                aligned_verts[idx] = export['verts'][vert_idx]
                aligned_normals[idx] = export['normals'][norm_idx]
                if faceuv:
                    aligned_uvs[idx] = export['uvs'][uv_idx]

            aligned_f.append(idx)

        # update verts and flatten arrays
        export['verts'] = [item for sublist in aligned_verts for item in sublist]
        export['normals'] = [item for sublist in aligned_normals for item in sublist]
        if faceuv:
            export['uvs'] = [item for sublist in aligned_uvs for item in sublist]
        export['faces'] = aligned_f

        # Make the indices global rather then per mesh
        totverts += len(me_verts)
        totuvco += uv_unique_count
        totno += no_unique_count

        export["materials"] = SceneObjectParser.export_mat(obj, scene, mtl_dict)

        # clean up
        if cloning_mesh:
            bpy.data.meshes.remove(me)

        return export

    @staticmethod
    def export_obj(obj, trans_mat, scene):
        return SceneObjectParser.export_mesh(obj, trans_mat, scene)

    @staticmethod
    def flatten_matrix(matrix):
        mat_array = []
        for col in matrix.col:
            for val in col:
                mat_array.append(val)

        return mat_array

    @staticmethod
    def serailise_scene_object(obj, correction_matrix=Matrix(), so=None):
        """
        API reference:
        https://docs.blender.org/api/blender_python_api_2_63_2/bpy.types.Mesh.html
        :param obj: Blender scene object
        :param correction_matrix: transformation multiplied with the PARENTS (depth 0) local transformation matrix to correct
        :param so: existing scene object, if not null then will serialise from the screen otherwise just amend some metadata
        :return: serialised blender object
        """
        matrix = correction_matrix * obj.matrix_local.copy()
        transform = SceneObjectParser.flatten_matrix(matrix)

        if so is None:
            #transformation_matrix = Matrix()
            #Matrix.identity(transformation_matrix)

            scene = bpy.data.scenes[0]
            dict = SceneObjectParser.export_obj(obj, mathutils.Matrix(), scene)

            vertices = dict['verts']

            normals = dict['normals']

            indices = dict['faces']

            uvs = dict['uvs']

            materials = dict['materials']

            so = SceneObject(
                name=obj.name,
                mode=obj.mode,
                transform=transform,
                vertices=vertices,
                normals=normals,
                faces=indices,
                uvs=uvs,
                materials=materials
            )

            for child in obj.children:
                so.children.append(
                    SceneObjectParser.serailise_scene_object(child)
                )
        else:
            so.mode = obj.mode
            so.transform = transform

        return so