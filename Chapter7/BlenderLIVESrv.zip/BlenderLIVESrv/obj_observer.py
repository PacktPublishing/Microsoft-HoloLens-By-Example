from locale import currency

from .singleton import Singleton
from .scene_parser import SceneObject, SceneObjectParser
from .obj_sync_srv import ObjectSyncService
import bpy
import json
import time
import struct
import math
import bpy
import mathutils
import queue

class ObjectObserver(metaclass=Singleton):
    TYPE_OBJECT_UPDATE = 1
    TYPE_MATERIAL_TEXTURE_REQUEST = 2
    TYPE_MATERIAL_TEXTURE = 3
    TYPE_OBJECT_REMOVE = 4
    TYPE_OBJECT_OPERATION = 5
    TYPE_OBJECT_WORLDANCHOR = 6
    TYPE_OBJECT_WORLDANCHOR_REQUEST = 7

    MODE_OBJECT = 'OBJECT'
    MODE_EDIT = 'EDIT'

    TAG_REFRESH = 'REFRESH'

    HISTORY_SIZE = 2

    def __init__(self):
        self.cached_objects = {}
        self.cached_objects_worldanchor = {}
        self.observed_objects = []
        self.history = {}

        ObjectSyncService().on_client_connected_handler = self.on_client_connected
        ObjectSyncService().on_client_disconnected_handler = self.on_client_disconnected
        ObjectSyncService().on_client_data_received_handler = self.on_client_data_received

    def reset(self):
        self.cached_objects = {}
        self.cached_objects_worldanchor = {}
        self.observed_objects = []
        self.history = {}

    def register_object(self, obj):
        if obj in self.observed_objects:
            return

        print("registering {}".format(obj))

        self.observed_objects.append(obj)
        self.history[obj.name] = []

        self.on_object_updated(obj, obj, ObjectObserver.MODE_OBJECT)

        if len(self.observed_objects) == 1:
            # start listening to update events
            bpy.app.handlers.scene_update_post.append(self.on_scene_update_post)

    def unregister_object(self, obj):
        if obj not in self.observed_objects:
            return

        self.observed_objects.remove(obj)
        del self.history[obj.name]

        if obj.name in self.cached_objects:
            obj_name = obj.name
            del self.cached_objects[obj_name]

            if obj_name in self.cached_objects_worldanchor:
                del self.cached_objects_worldanchor[obj_name]

        self.on_object_removed(obj.name)

        if len(self.observed_objects) == 0:
            # stop listening for scene updates
            bpy.app.handlers.scene_update_post.clear()

    @property
    def correction_matrix(self):
        # mat_rot = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')
        # mat_sca = mathutils.Matrix.Scale(0.1, 4, (1.0, 1.0, 1.0))
        # #mat_sca = mathutils.Matrix()
        # mat_loc = mathutils.Matrix()
        # return mat_loc * mat_rot * mat_sca
        return mathutils.Matrix()

    def is_observing_object(self, obj):
        return obj in self.observed_objects

    def on_scene_update_post(self, blender_scene):
        for obj in blender_scene.objects:
            if obj not in self.observed_objects:
                continue

            updated_obj, updated_mode = self.get_updated_object_and_mode(obj)

            if updated_obj is None:
                continue

            """
            TRANSFORM_OT_translate
            TRANSFORM_OT_translate
            OBJECT_OT_editmode_toggle
            ...
            """
            self.on_object_updated(
                obj,
                updated_obj,
                updated_mode,
                bpy.context.window_manager.operators[-1].bl_idname if len(bpy.context.window_manager.operators) > 0 else "UNKNOWN"
            )

    def get_updated_object_and_mode(self, obj):
        q = queue.Queue()
        q.put(obj)

        while not q.empty():
            current_obj = q.get()

            if current_obj.data.is_updated or current_obj.data.is_updated_data:
                return current_obj, ObjectObserver.MODE_EDIT

            if current_obj.is_updated or current_obj.is_updated_data:
                return current_obj, ObjectObserver.MODE_OBJECT

            for child_obj in current_obj.children:
                q.put(child_obj)

        return None, None

    def get_packet_for_obj(self, obj, updated_obj, updated_mode, tag=TAG_REFRESH):

        refetch_obj = tag == ObjectObserver.TAG_REFRESH \
                or updated_mode == ObjectObserver.MODE_EDIT \
                or updated_obj.name != obj.name \
                or obj.name not in self.cached_objects

        #print("using refetching object {}".format(refetch_obj))

        if refetch_obj:
            so = SceneObjectParser.serailise_scene_object(obj, self.correction_matrix)
        else:
            so = SceneObjectParser.serailise_scene_object(obj, self.correction_matrix, self.cached_objects[obj.name])

        self.cached_objects[obj.name] = so

        fmt = "<"
        data = []

        # type
        fmt += "B"
        data.append(ObjectObserver.TYPE_OBJECT_UPDATE)

        # packet size
        fmt += "i"
        data.append(0)

        # tag
        fmt += "B{}s".format(len(tag))
        data.append(len(tag))
        data.append(bytes(tag, 'utf-8'))

        # timestamp
        fmt += "f"
        data.append(time.time() * 1000)

        # updated object
        fmt += "B{}s".format(len(updated_obj.name))
        data.append(len(updated_obj.name))
        data.append(bytes(updated_obj.name, 'utf-8'))

        # updated mode (edit, object)
        fmt += "B{}s".format(len(updated_mode))
        data.append(len(updated_mode))
        data.append(bytes(updated_mode, 'utf-8'))

        # world anchor
        fmt += "B"
        if obj.name in self.cached_objects_worldanchor:
            data.append(1)
        else:
            data.append(0)

        fmt, data = so.get_pack_fmt_and_bytes(refetch_obj, fmt, data)
        packet = bytearray(struct.pack(fmt, *data))

        # update packet size
        packet_size = struct.pack("<i", len(packet))
        for i in range(1, 5):
            packet[i] = packet_size[i-1]

        return packet

    def on_object_updated(self, obj, updated_obj, updated_mode, tag=TAG_REFRESH):
        #print("on_object_updated {} {} {}".format(obj.name, updated_obj.name, tag))
        # create packet (appending tag to let the receiver know of the operation applied)

        packet = self.get_packet_for_obj(obj, updated_obj, updated_mode, tag)

        self.history[obj.name].append(packet)

        exceeded_size = len(self.history[obj.name]) - ObjectObserver.HISTORY_SIZE

        if  exceeded_size > 0:
            self.history[obj.name] = self.history[obj.name][exceeded_size:]

        target_addrs = list(ObjectSyncService().clients)

        ObjectSyncService().enqueue_packet(
            obj.name,
            packet,
            source_addr=None,
            target_addrs=target_addrs
        )

    def on_object_removed(self, obj_name):
        fmt = "<"
        data = []

        packet_key = "{}_removed".format(obj_name)

        # type
        fmt += "B"
        data.append(ObjectObserver.TYPE_OBJECT_REMOVE)

        # packet size (placeholder)
        fmt += "i"
        data.append(0)

        # tag
        fmt += "B{}s".format(len(obj_name))
        data.append(len(obj_name))
        data.append(bytes(obj_name, 'utf-8'))

        packet = bytearray(struct.pack(fmt, *data))

        # update packet size value
        packet_size = struct.pack("<i", len(packet))
        for i in range(1, 5):
            packet[i] = packet_size[i - 1]

        target_addrs = list(ObjectSyncService().clients)

        # send packet
        ObjectSyncService().enqueue_packet(
            packet_key,
            packet,
            source_addr=None,
            target_addrs=target_addrs
        )

    def on_client_connected(self, addr):
        '''
        send object data to client
        '''
        print("on_client_connected {}".format(addr))
        self.send_observed_objects_to_client(addr)

    def on_client_disconnected(self, addr):
        pass

    def on_client_data_received(self, addr, data):
        if data[0] == ObjectObserver.TYPE_OBJECT_UPDATE:
            self.on_client_requested_object_update(addr, data)

        elif data[0] == ObjectObserver.TYPE_MATERIAL_TEXTURE_REQUEST:
            self.on_client_requested_material_texture(addr, data)

        elif data[0] == ObjectObserver.TYPE_OBJECT_OPERATION:
            self.on_client_object_operation(addr, data)

        elif data[0] == ObjectObserver.TYPE_OBJECT_WORLDANCHOR:
            self.on_client_object_worldanchor(addr, data)

        elif data[0] == ObjectObserver.TYPE_OBJECT_WORLDANCHOR_REQUEST:
            self.on_client_requested_object_worldanchor(addr, data)

    def on_client_requested_object_update(self, addr, data):
        print("on_client_requested_object_update")

        self.send_observed_objects_to_client(addr)

    def on_client_requested_material_texture(self, addr, data):
        print("on_client_requested_material_texture")
        # get all textures
        request_images = []

        # int (number of images)
        count = struct.unpack("<i", data[5:5 + 4])[0]

        print("requesting {} images".format(count))

        current_index = 5 + 4
        for i in range(count):
            str_len = data[current_index]
            current_index += 1
            str = data[current_index:current_index + str_len].decode("utf-8")
            request_images.append(str)

            print("requesting {}".format(str))

            current_index += str_len

        # find all images
        self.send_images_to_client(addr, request_images)

    def on_client_object_operation(self, addr, data):
        current_index = 1 + 4 # type, packet size

        # name of object
        str_len = data[current_index]
        current_index += 1
        obj_name = data[current_index:current_index + str_len].decode("utf-8")
        current_index += str_len

        # operation type
        op_type = data[current_index]
        current_index += 1

        # operation values
        x = struct.unpack("<f", data[current_index: current_index + 4])[0]
        current_index += 4
        y = struct.unpack("<f", data[current_index: current_index + 4])[0]
        current_index += 4
        z = struct.unpack("<f", data[current_index: current_index + 4])[0]

        self.apply_operation(self.find_object_with_name(obj_name), op_type, x, y, z)

    def apply_operation(self, obj, op_type, x, y, z):
        OP_TYPE_ROTATE = 1
        OP_TYPE_TRANSLATE = 2
        OP_TYPE_SCALE = 3
        OP_TYPE_SET_ROTATION = 4
        OP_TYPE_SET_POSITION = 5
        OP_TYPE_SET_SCALE = 6

        if obj is None:
            return

        if op_type == OP_TYPE_ROTATE:
            obj.rotation_euler[0] += math.radians(x)
            obj.rotation_euler[1] += math.radians(y)
            obj.rotation_euler[2] += math.radians(z)
        elif op_type == OP_TYPE_TRANSLATE:
            obj.location[0] += x
            obj.location[1] += y
            obj.location[2] += z
        elif op_type == OP_TYPE_SCALE:
            obj.scale[0] += x
            obj.scale[1] += y
            obj.scale[2] += z
        elif op_type == OP_TYPE_SET_ROTATION:
            obj.rotation_euler[0] = math.radians(x)
            obj.rotation_euler[1] = math.radians(y)
            obj.rotation_euler[2] = math.radians(z)
        elif op_type == OP_TYPE_SET_POSITION:
            obj.location[0] = x
            obj.location[1] = y
            obj.location[2] = z
        elif op_type == OP_TYPE_SET_SCALE:
            obj.scale[0] = x
            obj.scale[1] = y
            obj.scale[2] = z

    def find_object_with_name(self, obj_name):
        for obj in bpy.data.objects:
            if obj.name == obj_name:
                return obj

        return None

    def on_client_object_worldanchor(self, addr, data):
        print("on_client_object_worldanchor from {} size {}".format(addr, len(data)))
        current_index = 1 + 4  # type, packet size

        # name of object
        str_len = data[current_index]
        current_index += 1
        obj_name = data[current_index:current_index + str_len].decode("utf-8")
        current_index += str_len

        worldanchor_data_len = struct.unpack("<i", data[current_index: current_index + 4])[0]
        current_index += 4

        print("worldanchor data length {}".format(worldanchor_data_len))

        world_anchor_id = 0
        if obj_name in self.cached_objects_worldanchor:
            world_anchor_id = self.cached_objects_worldanchor[obj_name][0]
            world_anchor_id += 1

        self.cached_objects_worldanchor[obj_name] = (world_anchor_id, data[current_index:current_index + worldanchor_data_len])

        client_addrs = list(ObjectSyncService().clients)
        target_addrs = []
        for client_addr in client_addrs:
            if client_addr in ObjectSyncService().clients:
                ObjectSyncService().clients[client_addr].worldAnchorId = world_anchor_id
                if client_addr != addr:
                    target_addrs.append(client_addr)

        print("caching worldanchor for object {} of size {}".format(obj_name, len(self.cached_objects_worldanchor[obj_name][1])))

        if len(target_addrs) > 0:

            ObjectSyncService().enqueue_packet(
                obj_name,
                data,
                source_addr=addr,
                target_addrs=target_addrs
            )

    def on_client_requested_object_worldanchor(self, addr, data):
        print("on_client_requested_object_worldanchor from {} size {}".format(addr, len(data)))
        current_index = 1 + 4  # type, packet size

        # name of object
        str_len = data[current_index]
        current_index += 1
        obj_name = data[current_index:current_index + str_len].decode("utf-8")

        if obj_name not in self.cached_objects_worldanchor:
            print("WARNING: {} doesn't have a cached world anchor", obj_name)
            return

        # type
        fmt = "<B"
        data_out = [ObjectObserver.TYPE_OBJECT_WORLDANCHOR]

        # packet size
        fmt += "i"
        data_out.append(0)

        # obj_name
        fmt += "B{}s".format(len(obj_name))
        data_out.append(len(obj_name))
        data_out.append(bytes(obj_name, 'utf-8'))

        # world anchor
        world_anchor_data = self.cached_objects_worldanchor[obj_name][1]
        world_anchor_data_len = len(world_anchor_data)
        fmt += "i{}B".format(world_anchor_data_len)
        data_out.append(world_anchor_data_len)
        data_out.extend(world_anchor_data)

        # update client with latest world anchor id

        if addr in ObjectSyncService().clients:
            ObjectSyncService().clients[addr].world_anchor_id = self.cached_objects_worldanchor[obj_name][0]

        packet = bytearray(struct.pack(fmt, *data_out))

        # update packet size
        packet_size = struct.pack("<i", len(packet))
        for i in range(1, 5):
            packet[i] = packet_size[i - 1]

        # send packet
        ObjectSyncService().enqueue_packet(
            "{}_{}_{}".format(addr, ObjectObserver.TYPE_OBJECT_WORLDANCHOR, obj_name),
            packet,
            source_addr=addr,
            target_addrs=[addr]
        )

    def send_images_to_client(self, addr, request_images):
        print("send_images_to_client {}".format(len(request_images)))

        packet_key = ""

        # load image data
        loaded_image_data = {}
        for image_name in request_images:

            if len(packet_key) > 0:
                packet_key += "_"

            packet_key += image_name

            for _, so in self.cached_objects.items():
                mat = so.find_material_with_texture(image_name)
                if mat is None:
                    print("could not find image with name {}".format(image_name))
                    continue

                image_data = self.load_image_data(mat['face_image'])
                image_data_width = mat['face_image_width']
                image_data_height = mat['face_image_height']
                loaded_image_data[image_name] = (image_data, image_data_width, image_data_height)

                print('loaded {} of size {}'.format(image_name, len(image_data)))

        if len(loaded_image_data) == 0:
            print("no images found")
            return

        # type
        fmt = "<B"
        data = [ObjectObserver.TYPE_MATERIAL_TEXTURE]

        # packet size
        fmt += "i"
        data.append(0)

        # image count
        fmt += "B"
        data.append(len(loaded_image_data))

        # pack image data
        for key, val in loaded_image_data.items():

            image_data = val[0]
            image_width = val[1]
            image_height = val[2]

            print("image_width {} image_height {} data len {}".format(image_width, image_height, len(image_data)))

            # image width
            fmt += "i"
            data.append(int(image_width))

            # image height
            fmt += "i"
            data.append(int(image_height))

            # image data length and image data bytes
            fmt += "i{}B".format(len(image_data))
            data.append(len(image_data))
            data.extend(image_data)

            # image name
            fmt += "B{}s".format(len(key))
            data.append(len(key))
            data.append(bytes(key, 'utf-8'))

        packet = bytearray(struct.pack(fmt, *data))

        # update packet size
        packet_size = struct.pack("<i", len(packet))
        for i in range(1, 5):
            packet[i] = packet_size[i-1]

        # send packet
        ObjectSyncService().enqueue_packet(
            packet_key,
            packet,
            source_addr=addr,
            target_addrs=[addr]
        )

    def load_image_data(self, image_path):
        if image_path is None or len(image_path) < 2:
            return None

        image_file_path = image_path
        if image_file_path[:2] == '//':
            image_file_path = image_file_path.replace('//', bpy.path.abspath("//"))

        b = None

        with open(image_file_path, "rb") as image_file:
            f = image_file.read()
            b = bytearray(f)
            b = list(b)

        return b

    def send_observed_objects_to_client(self, addr):
        for obj in bpy.data.objects:
            if obj not in self.observed_objects:
                continue

            packet = self.get_packet_for_obj(obj, obj, ObjectObserver.MODE_OBJECT, ObjectObserver.TAG_REFRESH)

            ObjectSyncService().enqueue_packet(
                obj.name,
                packet,
                source_addr=None,
                target_addrs=[addr]
            )


