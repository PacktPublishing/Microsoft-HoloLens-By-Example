import socket
import json
from singleton import Singleton
import threading

class CDBlendClient():

    def __init__(self):
        self.receive_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.send_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self, host, rport, sport):
        self.receive_socket.connect((host, rport))
        #self.receive_socket.send(b'0')

        # self.send_socket.connect((host, sport))

    def send(self, msg):
        # return self.send_socket.send(msg)
        return self.receive_socket.send(msg)

    def receive(self):
        while True:
            resp = (self.receive_socket.recv(2056))
            if resp:
                break

        return resp

if __name__ == "__main__":
    client = CDBlendClient()
    client.connect("localhost", 5559, 5558)
    while True:
        print(str(client.receive()))
        print("SENDING")
        client.send(json.dumps({'tag': 'REFRESH'}).encode())