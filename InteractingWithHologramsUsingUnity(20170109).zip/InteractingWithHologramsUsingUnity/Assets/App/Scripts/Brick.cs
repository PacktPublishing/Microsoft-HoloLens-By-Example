﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick : MonoBehaviour {

    public enum BlockColors : int
    {
        Red = 0,
        Green = 1,
        Blue = 2
    }

    public BlockColors _blockColor; 

    public BlockColors BlockColor
    {
        get { return _blockColor; }
        set
        {
            _blockColor = value;

            OnBlockTypeChanged(); 
        }
    }

    public Color Color
    {
        get
        {
            switch (BlockColor)
            {
                case BlockColors.Red:
                    return new Color(193f/255f, 0f, 44f/255f);
                case BlockColors.Green:
                    return new Color(193f/255f, 25f/255f, 0f);
                case BlockColors.Blue:
                    return new Color(239f/255f, 0f, 1f);
            }

            return new Color(0.6f, 0.6f, 0.6f); 
        }
    }


    void Start () {
        BlockColor = BlockColor; // force the color to reset 
	}
	
	void Update () {
		
	}

    void OnBlockTypeChanged()
    {
        var mr = GetComponent<MeshRenderer>();
        mr.material.color = Color; 
    }
}
