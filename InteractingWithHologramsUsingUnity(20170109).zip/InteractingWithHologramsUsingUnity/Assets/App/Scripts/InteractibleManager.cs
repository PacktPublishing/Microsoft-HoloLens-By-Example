﻿using System; 
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HoloToolkit.Unity;
using HoloToolkit.Unity.InputModule; 

public class InteractibleManager : Singleton<InteractibleManager> {

    private Interactible _currentInteractible; 

    public Interactible CurrentInteractible
    {
        get { return _currentInteractible; }
        set
        {
            if(_currentInteractible == value)
            {
                return; 
            }

            if(_currentInteractible != null)
            {
                _currentInteractible.GazeExited(); 
            }

            _currentInteractible = value;

            if (_currentInteractible != null)
            {
                _currentInteractible.GazeEntered(); 
            }
        }
    }

    private bool _locked = false; 

    public bool Locked
    {
        get { return _locked; }
        set
        {
            _locked = value;

            if (!_locked)
            {
                GameObject currentHitObject = GazeManager.Instance.HitObject; 
                if(currentHitObject == null)
                {
                    CurrentInteractible = null; 
                }
                else
                {
                    var interactible = currentHitObject.GetComponent<Interactible>();
                    CurrentInteractible = interactible;
                }
                
            }
        }
    }

    void Start () {
        GazeManager.Instance.FocusedObjectChanged += GazeManager_FocusedObjectChanged;
	}            

    protected override void OnDestroy()
    {
        GazeManager.Instance.FocusedObjectChanged -= GazeManager_FocusedObjectChanged;

        base.OnDestroy();
    }

    void GazeManager_FocusedObjectChanged(GameObject previousObject, GameObject newObject)
    {
        if (Locked)
        {
            return; 
        }

        if(newObject == null)
        {
            CurrentInteractible = null;
        }
        else
        {
            var interactible = newObject.GetComponent<Interactible>();
            CurrentInteractible = interactible;
        }
    }
}
