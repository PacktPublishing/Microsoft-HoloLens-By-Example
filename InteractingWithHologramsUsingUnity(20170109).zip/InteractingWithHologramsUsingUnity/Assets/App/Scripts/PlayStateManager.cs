﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HoloToolkit.Unity;

public class PlayStateManager : Singleton<PlayStateManager> {

    public GameObject brickPrefab;

    public List<GameObject> bricks = new List<GameObject>();  

    void Start () {
		
	}
	
	void Update () {
		if(SceneManager.Instance.State != SceneManager.States.Playing)
        {
            return; 
        }
	}

    public void PlaceBricks()
    {
        RobotController robot = SceneManager.Instance.robotController;

        Vector3 frontPos = robot.transform.position + (robot.transform.forward * robot.GetBounds(RobotController.BoundsType.Placement).extents.z);
        Vector3 leftPos = frontPos + (-robot.transform.right * robot.GetBounds(RobotController.BoundsType.Placement).extents.x);
        Vector3 rightPos = frontPos + (robot.transform.right * robot.GetBounds(RobotController.BoundsType.Placement).extents.x);


    }

    public void DestroyBricks()
    {
        while(bricks.Count > 0)
        {
            GameObject go = bricks[bricks.Count-1];
            bricks.RemoveAt(bricks.Count - 1);

            Destroy(go); 
        }
    }
}
