﻿using System; 
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HoloToolkit.Unity;
using HoloToolkit.Unity.InputModule;

/// <summary>
/// Simplied version of the HoloTookit Cursor script 
/// </summary>
public class BasicCursor : MonoBehaviour {

    /// <summary>
    /// Minimum distance for cursor if nothing is hit
    /// </summary>
    [Tooltip("The minimum distance the cursor can be with nothing hit")]
    public float MinCursorDistance = 1.0f;

    /// <summary>
    /// Maximum distance for cursor if nothing is hit
    /// </summary>
    [Tooltip("The maximum distance the cursor can be with nothing hit")]
    public float DefaultCursorDistance = 2.0f;

    /// <summary>
    /// Surface distance to place the cursor off of the surface at
    /// </summary>
    [Tooltip("The distance from the hit surface to place the cursor")]
    public float SurfaceCursorDistance = 0.02f;

    /// <summary>
    /// Blend value for surface normal to user facing lerp
    /// </summary>
    [Header("Motion")]
    public float PositionLerpTime = 0.01f;

    /// <summary>
    /// Blend value for surface normal to user facing lerp
    /// </summary>
    public float ScaleLerpTime = 0.01f;

    /// <summary>
    /// Blend value for surface normal to user facing lerp
    /// </summary>
    public float RotationLerpTime = 0.01f;

    /// <summary>
    /// Blend value for surface normal to user facing lerp
    /// </summary>
    [Range(0, 1)]
    public float LookRotationBlend = 0.5f;

    /// <summary>
    /// Indicates if hand is current in the view
    /// </summary>
    protected bool IsHandVisible;

    protected bool IsInputSourceDown;

    protected GameObject targetedObject;

    /// <summary>
    /// Position, scale and rotational goals for cursor
    /// </summary>
    private Vector3 targetPosition;
    private Vector3 targetScale;
    private Quaternion targetRotation;

    // Use this for initialization
    void Start () {
        GazeManager.Instance.FocusedObjectChanged += OnFocusedObjectChanged;
    }

    protected virtual void OnEnable() { }

    protected virtual void OnDisable()
    {
       
    }

    private void OnDestroy()
    {
        if(GazeManager.Instance != null)
        {
            GazeManager.Instance.FocusedObjectChanged -= OnFocusedObjectChanged;
        }        
    }        
	
	// Update is called once per frame
	void Update () {
        UpdateCursorState();
        UpdateCursorTransform(); 
	}

    void UpdateCursorState()
    {

    }

    protected void UpdateCursorTransform()
    {
        // Get the necessary info from the gaze source
        RaycastHit hitResult = GazeManager.Instance.HitInfo;
        GameObject newTargetedObject = GazeManager.Instance.HitObject;

        // Get the forward vector looking back at camera
        Vector3 lookForward = -GazeManager.Instance.GazeNormal;

        // Normalize scale on before update
        targetScale = Vector3.one;

        // If no game object is hit, put the cursor at the default distance
        if (targetedObject == null)
        {
            this.targetedObject = null;
            targetPosition = GazeManager.Instance.GazeOrigin + GazeManager.Instance.GazeNormal * DefaultCursorDistance;
            targetRotation = lookForward.magnitude > 0 ? Quaternion.LookRotation(lookForward, Vector3.up) : transform.rotation;
        }
        else
        {
            // Update currently targeted object
            this.targetedObject = newTargetedObject;

            // If no modifier is on the target, just use the hit result to set cursor position
            targetPosition = hitResult.point + (lookForward * SurfaceCursorDistance);
            targetRotation = Quaternion.LookRotation(Vector3.Lerp(hitResult.normal, lookForward, LookRotationBlend), Vector3.up);
        }

        // Use the lerp times to blend the position to the target position
        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime / PositionLerpTime);
        transform.localScale = Vector3.Lerp(transform.localScale, targetScale, Time.deltaTime / ScaleLerpTime);
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.deltaTime / RotationLerpTime);
    }

    protected virtual void OnFocusedObjectChanged(GameObject previousObject, GameObject newObject)
    {
        targetedObject = newObject;
    }
}
